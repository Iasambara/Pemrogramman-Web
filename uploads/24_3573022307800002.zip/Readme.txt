Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/how-to-upload-and-extract-zip-file-in-codeigniter/

Instructions - 

* base_url
Rename the folder and edit $config['base_url'] in application/config/config.php